# Guardrail UI results - PLACEHOLDER (Task 5)

TODO: Replace this whole file with the results file downloaded from the
SecureAssist web UI. Do not edit the downloaded file and do not type results
by hand.

1. Open http://<VM-IP>:8091 -> tab "Guardrail Tests".
2. Click "Run all tests" and wait until all 17 tests have run (1-3 minutes).
3. Click "Download results".
4. Move the downloaded file here, keeping this exact name:
       mv ~/Downloads/guardrail-ui-results.md reports/guardrail-ui-results.md

scripts/verify-deployment.sh reads the result line of the DOWNLOADED file and
reports "UI test suite results" as FAIL while this placeholder is still here.
Expected after a correct implementation: 17 of 17 tests passed.

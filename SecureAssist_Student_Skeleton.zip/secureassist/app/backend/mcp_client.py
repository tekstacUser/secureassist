"""MCP client used by the SecureAssist backend.

STUDENT TASK (Task 2c): Complete the MCP tool allowlist, the argument
validators, tool discovery and the safety checks in call_tool().

This is a genuine Model Context Protocol client built on the official SDK
(`mcp` package, same pinned version as the server). For every call it:

  1. checks the tool name against the local ALLOWLIST (rejected before any
     network traffic if not approved),
  2. validates the arguments,
  3. opens an MCP session over Streamable HTTP and runs `initialize`,
  4. discovers tools with `tools/list` and confirms the server offers the tool,
  5. invokes it with `tools/call`, within a timeout.

What is PROVIDED (do not modify):
  - imports, MCP_SERVER_URL, MCP_TIMEOUT, APPROVED_SERVICES
  - MCPError, _unwrap(), _with_session(), _run()  (async session + error handling)
  - the result-parsing part of call_tool(), check_server(), the command line

What YOU implement (numbered TODOs below):
  - TODO 1  _validate_faq_args()
  - TODO 2  _validate_status_args()
  - TODO 3  ALLOWED_TOOLS (the allowlist)
  - TODO 4  list_tools()  -> build the discovered-tools list
  - TODO 5  call_tool()   -> allowlist + argument checks BEFORE any network call
  - TODO 6  call_tool()   -> confirm the server really offers the tool

Every unfinished part contains a placeholder `raise` line that names its TODO.
An incomplete client therefore fails SAFELY (no tool is ever called) and the
UI shows which TODO is still missing. Delete each placeholder when you finish
the TODO above it.

Error categories (the UI, the 17 UI tests and verify-deployment.sh expect
these exact strings):
  mcp_tool_not_allowed, mcp_invalid_arguments, mcp_tool_not_offered,
  mcp_tool_error, mcp_invalid_result, mcp_timeout, mcp_unreachable,
  mcp_protocol_error

Command-line verification (from the VM with a port-forward, or inside the
backend Pod with `kubectl exec`):

    python mcp_client.py list
    python mcp_client.py call search_support_faq '{"query": "reset password"}'
    python mcp_client.py call get_service_status '{"service": "vpn"}'
    python mcp_client.py call run_shell '{"cmd": "id"}'      # must be rejected
"""

import asyncio
import json
import os
import sys

import httpx
from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client

MCP_SERVER_URL = os.getenv("MCP_SERVER_URL", "http://secureassist-mcp:8093/mcp")
MCP_TIMEOUT = float(os.getenv("MCP_TIMEOUT", "10"))

# The only service names get_service_status may be asked about.
APPROVED_SERVICES = {"email", "vpn", "sso", "wifi", "printing", "helpdesk-portal"}


# ------------------------------------------------------------
# Error type - provided implementation
# ------------------------------------------------------------

class MCPError(Exception):
    """Raised for any MCP failure. `category` is safe to log and show."""

    def __init__(self, category: str, message: str):
        super().__init__(message)
        self.category = category


# ------------------------------------------------------------
# Argument validators
# ------------------------------------------------------------

def _validate_faq_args(args: dict) -> dict:
    """Validate the arguments for search_support_faq. Returns clean arguments."""

    # TODO 1: Validate the arguments for search_support_faq.
    #
    # The ONLY allowed shape is:  {"query": "<text of 1-200 characters>"}
    #
    # Step 1: Read the value:   query = args.get("query")
    #
    # Step 2: Reject the arguments if ANY of these is true:
    #   - the dictionary has keys other than "query"   ->  set(args) != {"query"}
    #   - query is not a string                        ->  not isinstance(query, str)
    #   - the stripped query is shorter than 1 or longer than 200 characters
    #                                                  ->  not 1 <= len(query.strip()) <= 200
    #
    #   In that case raise:
    #   MCPError("mcp_invalid_arguments", "search_support_faq needs {'query': 1-200 chars}")
    #
    # Step 3: Return the cleaned arguments:  {"query": query.strip()}

    # Placeholder: rejects every call until TODO 1 is done. Remove it when you are finished.
    raise MCPError("mcp_invalid_arguments", "Task 2c TODO 1 not completed: _validate_faq_args()")


def _validate_status_args(args: dict) -> dict:
    """Validate the arguments for get_service_status. Returns clean arguments."""

    # TODO 2: Validate the arguments for get_service_status.
    #
    # The ONLY allowed shape is:  {"service": "<one of APPROVED_SERVICES>"}
    #
    # Step 1: Read the value:   service = args.get("service")
    #
    # Step 2: If the dictionary has keys other than "service", or service is
    #         not a string, raise:
    #   MCPError("mcp_invalid_arguments", "get_service_status needs {'service': <name>}")
    #
    # Step 3: Normalise the name:   service = service.strip().lower()
    #         (so " VPN " becomes "vpn")
    #
    # Step 4: If service is not in APPROVED_SERVICES, raise:
    #   MCPError("mcp_invalid_arguments",
    #            f"service must be one of {sorted(APPROVED_SERVICES)}")
    #   Example: {"service": "payroll-db"} must be rejected here.
    #
    # Step 5: Return the cleaned arguments:  {"service": service}

    # Placeholder: rejects every call until TODO 2 is done. Remove it when you are finished.
    raise MCPError("mcp_invalid_arguments", "Task 2c TODO 2 not completed: _validate_status_args()")


# ------------------------------------------------------------
# Tool allowlist
# ------------------------------------------------------------

# TODO 3: Build the allowlist - the ONLY tools the backend may call.
#
# ALLOWED_TOOLS is a dictionary:  tool name (str) -> its validator function.
# Add exactly two entries:
#   "search_support_faq"  -> _validate_faq_args
#   "get_service_status"  -> _validate_status_args
#
# Hint: write the function NAME without brackets (do not call it), e.g.
#   {"tool_name": my_function}
#
# Never add any other tool (for example "run_shell"). While this dictionary is
# empty, every tool is rejected - a safe default, but the MCP features will not work.
ALLOWED_TOOLS = {}


# ------------------------------------------------------------
# Session handling - provided implementation (do not modify)
# ------------------------------------------------------------

def _unwrap(exc: BaseException) -> BaseException:
    """The SDK uses task groups, so real errors can be wrapped in ExceptionGroups."""
    while isinstance(exc, BaseExceptionGroup) and exc.exceptions:
        exc = exc.exceptions[0]
    return exc


async def _with_session(work):
    async with httpx.AsyncClient(timeout=MCP_TIMEOUT) as http_client:
        async with streamable_http_client(MCP_SERVER_URL, http_client=http_client) as (read, write, _):
            async with ClientSession(read, write) as session:
                await session.initialize()
                return await work(session)


def _run(work):
    try:
        return asyncio.run(asyncio.wait_for(_with_session(work), timeout=MCP_TIMEOUT + 2))
    except MCPError:
        raise
    except BaseException as exc:  # noqa: BLE001 - classify every failure clearly
        exc = _unwrap(exc)
        if isinstance(exc, MCPError):
            raise exc from None
        if isinstance(exc, (asyncio.TimeoutError, httpx.TimeoutException)):
            raise MCPError("mcp_timeout", f"MCP server did not answer within {MCP_TIMEOUT:.0f}s") from None
        if isinstance(exc, httpx.ConnectError):
            raise MCPError("mcp_unreachable", f"MCP server unreachable at {MCP_SERVER_URL}") from None
        if isinstance(exc, (KeyboardInterrupt, SystemExit)):
            raise
        raise MCPError("mcp_protocol_error", f"MCP error: {type(exc).__name__}: {exc}") from None


# ------------------------------------------------------------
# Tool discovery (MCP tools/list)
# ------------------------------------------------------------

def list_tools() -> list[dict]:
    """Discover tools on the server (MCP tools/list)."""

    async def work(session):
        # TODO 4: Discover the tools the MCP server offers.
        #
        # Step 1: Ask the server for its tools:
        #         result = await session.list_tools()
        #         result.tools is a list; each tool has .name and .description
        #
        # Step 2: Return a list with ONE dictionary per tool:
        #         {
        #             "name": t.name,
        #             "description": (t.description or "").strip(),
        #             "approved": t.name in ALLOWED_TOOLS,
        #         }
        #
        # Hint: a list comprehension works well:
        #       return [{...} for t in result.tools]
        #
        # Expected: 2 tools, search_support_faq and get_service_status,
        # both approved: true (MCP Tools tab in the browser).

        # Placeholder: reported as mcp_protocol_error until TODO 4 is done. Remove it when you are finished.
        raise NotImplementedError("Task 2c TODO 4 not completed: list_tools()")

    return _run(work)


# ------------------------------------------------------------
# Tool invocation (MCP tools/call)
# ------------------------------------------------------------

def call_tool(name: str, arguments: dict) -> dict:
    """Validate and invoke one approved tool. Returns the tool's JSON result."""

    # TODO 5: Run the safety checks BEFORE any network traffic.
    #
    # Step 1: If name is not in ALLOWED_TOOLS, raise:
    #   MCPError("mcp_tool_not_allowed", f"Tool '{name}' is not on the approved allowlist")
    #   (This is how "run_shell" is rejected.)
    #
    # Step 2: If arguments is not a dictionary, raise:
    #   MCPError("mcp_invalid_arguments", "arguments must be a JSON object")
    #   Hint: isinstance(arguments, dict)
    #
    # Step 3: Validate the arguments with the tool's own validator and keep
    #         the cleaned result in the variable clean_args:
    #   clean_args = ALLOWED_TOOLS[name](arguments)
    #
    # Placeholder: rejects every call until TODO 5 is done. Remove it when you are finished.
    raise MCPError("mcp_tool_not_allowed", "Task 2c TODO 5 not completed: call_tool() safety checks")

    async def work(session):
        # TODO 6: Confirm the server really offers this tool (discovery).
        #
        # Step 1: Collect the names the server offers:
        #   offered = {t.name for t in (await session.list_tools()).tools}
        #
        # Step 2: If name is not in offered, raise:
        #   MCPError("mcp_tool_not_offered", f"Server does not offer tool '{name}'")
        #
        # Write your code here, above the provided lines below.

        # ---- Provided: invoke the tool and parse the result (do not modify) ----
        result = await session.call_tool(name, clean_args)
        text = "".join(getattr(c, "text", "") for c in result.content)
        if result.isError:
            raise MCPError("mcp_tool_error", text[:300] or "tool returned an error")
        if isinstance(result.structuredContent, dict) and "result" not in result.structuredContent:
            return result.structuredContent
        try:
            data = json.loads(text)
        except ValueError:
            raise MCPError("mcp_invalid_result", "tool result was not valid JSON") from None
        if not isinstance(data, dict):
            raise MCPError("mcp_invalid_result", "tool result was not a JSON object")
        return data

    return _run(work)


# ------------------------------------------------------------
# Readiness helper and command line - provided implementation
# ------------------------------------------------------------

def check_server() -> dict:
    """Used by /ready?deep=true. Never raises."""
    try:
        tools = list_tools()
        return {"ok": True, "url": MCP_SERVER_URL, "tools": [t["name"] for t in tools]}
    except MCPError as exc:
        return {"ok": False, "url": MCP_SERVER_URL, "detail": exc.category}


if __name__ == "__main__":
    try:
        if len(sys.argv) >= 2 and sys.argv[1] == "list":
            print(json.dumps({"server": MCP_SERVER_URL, "tools": list_tools()}, indent=2))
        elif len(sys.argv) >= 3 and sys.argv[1] == "call":
            args = json.loads(sys.argv[3]) if len(sys.argv) > 3 else {}
            print(json.dumps({"tool": sys.argv[2], "result": call_tool(sys.argv[2], args)}, indent=2))
        else:
            print(__doc__)
            sys.exit(2)
    except MCPError as err:
        print(json.dumps({"error": err.category, "detail": str(err)}, indent=2))
        sys.exit(1)

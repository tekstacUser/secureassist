# Jenkins result

<!--
STUDENT EVIDENCE TEMPLATE (Task 6)

Fill this in AFTER you have run the `secureassist` pipeline job in Jenkins
(http://<VM-IP>:3030). Copy every value from the REAL build page, console
output and archived artifacts. Replace EVERY "TODO".

A FAILURE build is an acceptable, honest answer - then record the first red
stage and its error message. A fabricated SUCCESS is not acceptable.

scripts/verify-deployment.sh reports "Jenkins pipeline result recorded" as
FAIL while any TODO is left. Check: grep -c TODO reports/jenkins-result.md  -> 0
-->

- Job: secureassist   Build number: TODO
- Result: TODO: SUCCESS or FAILURE (exactly as shown on the build page)
- SonarQube quality gate: TODO: OK or ERROR (stage 5 console line "SonarQube quality gate: ..." or artifact reports/sonar-quality-gate.txt)
- Build URL: TODO: http://<VM-IP>:3030/job/secureassist/<number>/
- Date and time of the build (UTC): TODO
- Failed stage and reason (if any): TODO: stage name + error message, or "none"

## Stage results

<!-- Status of each stage from the Stage View or the console: PASSED, FAILED or SKIPPED. -->

| # | Stage | Status |
|---|---|---|
| 1 | Checkout | TODO |
| 2 | Environment and tool checks | TODO |
| 3 | Code checks | TODO |
| 4 | SonarQube analysis | TODO |
| 5 | SonarQube quality gate | TODO |
| 6 | Build Docker images | TODO |
| 7 | Load images into Minikube | TODO |
| 8 | Validate Kubernetes manifests | TODO |
| 9 | Deploy to Minikube | TODO |
| 10 | Deployment and health checks | TODO |

## Verification evidence (Build Artifacts -> reports/)

| Artifact | What it shows | Key line you observed |
|---|---|---|
| `capabilities.txt` | Jenkins can use docker, kubectl, minikube | TODO |
| `code-checks.txt` | syntax OK, no execution calls, no secrets | TODO |
| `sonar-quality-gate.txt` | quality gate status | TODO |
| `images.txt` | four images, user 10001/1001, ports | TODO |
| `k8s-status.txt` | five Deployments 1/1 | TODO |
| `verification-latest.md` | pipeline-mode verification | TODO: its OVERALL line |

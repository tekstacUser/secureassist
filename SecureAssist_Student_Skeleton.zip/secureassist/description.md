# SecureAssist — Scenario Description (Student Skeleton Edition)

## The organisation
A mid-sized enterprise runs an internal IT Service Desk for about 3,000 employees. Most tickets are repeat questions: password resets, VPN problems, printers, MFA set-up, Wi-Fi and "is service X down?". Agents spend hours answering the same things, and employees wait.

The platform team already operates, on a single lab VM:

* **Ollama** with the `phi3:mini` model (local inference, no data leaves the company),
* **Jenkins** (CI/CD) with **SonarQube** for code-quality gates,
* **Kubernetes** (Minikube) for workloads,
* GitLab for source control.

LLM observability (**Langfuse**, with its PostgreSQL database) is delivered with this project and runs as Pods next to the application, in the same Kubernetes namespace and network.

## The request
Leadership asked for **SecureAssist**, an internal AI helpdesk that:

1. Answers employees in a browser chat window.
2. Uses only **approved** support content, obtained through a standard tool protocol (**MCP**) so tools can be governed, allow-listed and audited.
3. Blocks attempts to extract passwords, keys or tokens and obvious prompt-injection attempts, and redacts secrets from answers.
4. Never executes anything the model says — answers are text only.
5. Runs as containers on Kubernetes, delivered by a Jenkins pipeline that **must pass a SonarQube quality gate** before anything is built or deployed.
6. Is observable in Langfuse without leaking prompt content or credentials.
7. Has a rehearsed incident-response procedure and auditable governance evidence.

## Your role
You are the platform engineer delivering the first production-like release. The frontend, the backend orchestrator, the Ollama client, the monitoring module, the Langfuse image and the scripts are provided. You will:

* implement the guardrails, the MCP server tools and the MCP client allowlist (security logic),
* containerise the frontend, the backend and the MCP server,
* write the Kubernetes deployment configuration for all three services,
* deploy and verify genuine MCP tool use,
* complete and run the Jenkins pipeline with SonarQube analysis and quality gate,
* break the release on purpose, diagnose it and recover,
* produce the evidence an auditor would ask for.

## Student working files (18)
Every file below contains numbered `TODO` instructions (code files) or a `TODO` evidence template (report files). Everything else in the project is provided and must not be changed.

| # | File | Task | What you implement |
|---:|---|:---:|---|
| 1 | `langfuse/.env` | 1 | Replace every `REPLACE_ME` with a random value (openssl); keep the file git-ignored |
| 2 | `app/backend/guardrails.py` | 2a | `check_input()` and `check_output()`: type, empty, length, secret request, prompt injection; control characters, truncation, redaction |
| 3 | `mcp_server/server.py` | 2b | FAQ keyword scoring, `@mcp.tool()` registration, `search_support_faq` and `get_service_status` |
| 4 | `app/backend/mcp_client.py` | 2c | Argument validators, `ALLOWED_TOOLS` allowlist, tool discovery (`list_tools`), allowlist + "tool offered" checks in `call_tool` |
| 5 | `app/frontend/Dockerfile` | 3 | Image `secureassist-frontend:1.0`, non-root UID 10001, port 8091, gunicorn |
| 6 | `app/backend/Dockerfile` | 3 | Image `secureassist-backend:1.0`, non-root UID 10001, port 8092, gunicorn |
| 7 | `mcp_server/Dockerfile` | 3 | Image `secureassist-mcp:1.0`, non-root UID 10001, port 8093, `python server.py` |
| 8 | `k8s/frontend-deployment.yaml` | 4 | Image, port, `BACKEND_URL`, probes, security context |
| 9 | `k8s/frontend-service.yaml` | 4 | ClusterIP Service `secureassist-frontend`, 8091 → `http` |
| 10 | `k8s/backend-deployment.yaml` | 4 | Image, port, MCP/Ollama/Langfuse settings, Secret references, probes, security context |
| 11 | `k8s/backend-service.yaml` | 4 | ClusterIP Service `secureassist-backend`, 8092 → `http` |
| 12 | `k8s/mcp-deployment.yaml` | 4 | Image, port, `MCP_HOST`/`MCP_PORT`, probes, security context |
| 13 | `k8s/mcp-service.yaml` | 4 | ClusterIP Service `secureassist-mcp`, 8093 → `http` |
| 14 | `reports/guardrail-ui-results.md` | 5 | Replace the placeholder with the file downloaded from the Guardrail Tests tab |
| 15 | `cicd/Jenkinsfile` | 6 | Stages 5–10: quality-gate enforcement, image build, image load, manifest validation, deploy, verification |
| 16 | `reports/jenkins-result.md` | 6 | Record the real Jenkins build result, stage results and artifacts |
| 17 | `reports/incident-timeline.log` | 7 | Timestamped drill steps written by the drill commands |
| 18 | `reports/incident-record.md` | 7 | Incident summary, evidence, analysis, recovery and outcome |

## Task-to-file mapping

**Task 1 — Environment and secrets (`langfuse/.env`).** Prove the VM is ready (`scripts/check-environment.sh`) and create the secrets that Langfuse, PostgreSQL and the backend will read from the Kubernetes Secret `secureassist-langfuse`. *Evidence:* `RESULT: 0 failure(s)`, `langfuse/.env complete`, `git check-ignore -v langfuse/.env` prints a rule.

**Task 2 — Guardrails and MCP tool security (`guardrails.py`, `mcp_server/server.py`, `mcp_client.py`).** The backend calls `check_input` before any dependency and `check_output` before showing any answer. The MCP server publishes exactly two read-only tools over Streamable HTTP (`/mcp` on 8093); the backend client discovers them with `tools/list`, enforces `ALLOWED_TOOLS` and validates arguments before any `tools/call`. *Evidence (after Task 4):* Guardrail Tests tab 17 of 17; MCP Tools tab shows two approved tools, `run_shell` → `mcp_tool_not_allowed`, `payroll-db` → `mcp_invalid_arguments`.

**Task 3 — Dockerfiles (frontend, backend, MCP server).** Package each service as a small, non-root image; the Langfuse image (`langfuse/Dockerfile`) is provided. *Evidence:* `docker image inspect` shows `User=10001` and ports 8091 / 8092 / 8093; all five images in `minikube image ls`.

**Task 4 — Kubernetes manifests (six files).** Deployments and ClusterIP Services connect by Service DNS name: frontend → `http://secureassist-backend:8092`, backend → `http://secureassist-mcp:8093/mcp`, backend → `http://secureassist-langfuse:3031`, backend → existing Ollama at `http://host.minikube.internal:11434`. *Evidence:* five Deployments `1/1`, PVC `Bound`, four green status lights in the UI.

**Task 5 — Verify in the web UI (`reports/guardrail-ui-results.md`).** Run all 17 UI tests, check MCP tools and chat routes, open a Langfuse trace. *Evidence:* downloaded results file with 17 of 17 passed.

**Task 6 — Jenkins + SonarQube (`cicd/Jenkinsfile`, `reports/jenkins-result.md`).** Complete stages 5–10 of the 10-stage pipeline; stages 1–4 are provided. *Evidence:* SUCCESS build with quality gate `OK` (or an honestly recorded failing stage).

**Task 7 — Incident drill (`reports/incident-timeline.log`, `reports/incident-record.md`).** Inject a wrong MCP hostname, observe the stuck rollout (protected by the backend readiness probe you wrote in Task 4 and `maxUnavailable: 0`), diagnose, roll back, re-verify, record. *Evidence:* timeline with five timestamped steps; record with no `TODO`.

**Task 8 — Governance and final verification.** `bash scripts/verify-deployment.sh` until **OVERALL: PASS**, then tick `docs/governance-checklist.md`.

## Expected outcomes
| Outcome | Evidence |
|---|---|
| Chatbot reachable at `http://<VM-IP>:8091` | browser test + verification report |
| Guardrails block secret requests and injection; redact secrets | UI **Guardrail Tests** tab (17 of 17 passed, downloaded results), blocked message in the chat |
| Real MCP tool discovery/invocation through an allowlist | UI **MCP Tools** tab (discovery + calls), MCP server logs, MCP badges in the chat |
| Real `phi3:mini` answers from the existing Ollama | verification report "Real Ollama phi3:mini response" |
| Four project images (+ PostgreSQL), five Ready Kubernetes workloads in one namespace | `minikube image ls`, `kubectl get deploy` |
| Jenkins pipeline with genuine pass/fail and SonarQube gate | Jenkins build, `reports/jenkins-result.md` |
| Langfuse traces | trace fetched from the Langfuse API by ID |
| Incident drill recorded | `reports/incident-record.md`, `reports/incident-timeline.log` |
| Governance checklist completed | `docs/governance-checklist.md`, `reports/verification-latest.md` = PASS |

## Constraints
* Reuse existing Ollama (`phi3:mini`) and SonarQube — do not install or duplicate them, do not download models. Run exactly one Langfuse instance (the project's Pods).
* Ports: frontend 8091, backend 8092, MCP server 8093, Langfuse 3031 (Jenkins 3030, Ollama 11434).
* All project components run as Pods in namespace `secureassist` (same network); only the existing Ollama stays on the VM.
* No automated test files are delivered; behaviour is verified on the running system.
* No `sudo`, no files outside the `secureassist/` directory, no real secrets in Git.
* Total time: about 110–115 minutes (10–15 understanding + about 97 hands-on + 5 buffer).

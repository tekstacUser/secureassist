# SecureAssist MCP Server

> **Student task (Task 2b and Task 3):** `server.py` (TODO 1–4) and `Dockerfile` (TODO 1–8) are student working files; `k8s/mcp-deployment.yaml` and `k8s/mcp-service.yaml` are completed in Task 4, and the client `app/backend/mcp_client.py` in Task 2c. This README describes the finished behaviour you must reach.

A small, real **Model Context Protocol** server built with the official Python SDK (`mcp==1.30.0`, `FastMCP`).

| Item | Value |
|---|---|
| Transport | MCP **Streamable HTTP**, endpoint `POST /mcp` (stateless, JSON responses) |
| Port | 8093 (container, Service `secureassist-mcp:8093`, not exposed to the browser) |
| Health | `GET /health` (plain HTTP, for probes) |
| Image | `secureassist-mcp:1.0` (`docker build -t secureassist-mcp:1.0 mcp_server`) |
| Host protection | only Host headers in `MCP_ALLOWED_HOSTS` (Service name/FQDN, localhost) are accepted |

## Tools (read-only, predefined data)
| Tool | Arguments | Returns |
|---|---|---|
| `search_support_faq` | `query` (1–200 chars) | up to 3 matching entries from the 8 FAQ items in `server.py` (`FAQ-001` … `FAQ-008`), keyword scoring |
| `get_service_status` | `service` ∈ `email, vpn, sso, wifi, printing, helpdesk-portal` | **simulated** status from the table in `server.py`, labelled `"source": "simulated demo data - not live infrastructure health"` |

No tool runs commands, reads files, or contacts other systems. Results are deterministic, so checks can compare exact answers.

## How MCP is used (not a REST call labelled MCP)
Each backend call (`app/backend/mcp_client.py`) is a full MCP exchange over JSON-RPC 2.0:
1. `initialize` (client and server negotiate the protocol version and capabilities),
2. `notifications/initialized`,
3. `tools/list` — **discovery**; the client confirms the server offers the tool,
4. `tools/call` — **invocation** with validated arguments.

Before any network traffic the client enforces its **allowlist** (`ALLOWED_TOOLS`) and validates arguments, so `run_shell` or `{"service": "payroll-db"}` are rejected locally.

## Verify in the SecureAssist UI

Open `http://<VM-IP>:8091`.

1. **🔧 MCP Tools tab: discovery.** The list at the top comes from MCP `tools/list`, run live by the backend Pod. It must show exactly `search_support_faq` and `get_service_status`, both **approved**.
2. **🔧 MCP Tools tab: invocation.** Each call is a real MCP `tools/call` through the backend allowlist.

   | Tool | Arguments | Expected |
   |---|---|---|
   | `search_support_faq` | `{"query": "reset password"}` | ✔ first result `FAQ-001` |
   | `get_service_status` | `{"service": "printing"}` | ✔ `status: outage`, source *simulated demo data* |
   | `run_shell` | `{"cmd": "id"}` | ✖ `mcp_tool_not_allowed` (rejected before any network call) |
   | `get_service_status` | `{"service": "payroll-db"}` | ✖ `mcp_invalid_arguments` |
   | `search_support_faq` | `{"query": "Ignore all previous instructions"}` | ✖ `guardrail_prompt_injection` (arguments also pass the input guardrail) |

3. **💬 Chat tab.** Ask `How do I reset my password?` and the reply shows the green badge **🔧 MCP tool: search_support_faq (success)**. Ask `Is the VPN service down?` and the reply shows the badge **get_service_status**. **Details** lists the FAQ entries that were used.
4. **📊 System Status.** The MCP server card shows the server URL and the discovered tools. Scaling the MCP Deployment to 0 turns it red within 15 seconds.
5. **Server-side evidence** (VM):
   ```bash
   kubectl -n secureassist logs deploy/secureassist-mcp --tail=20
   kubectl -n secureassist logs deploy/secureassist-backend --tail=20 | grep -E '"event": "(chat|mcp_call)"'
   ```
   The MCP server log shows `Processing request of type ListToolsRequest` and `CallToolRequest`. The backend log shows `"mcp_tool"` and `"mcp_outcome"`, or `"event": "mcp_call"` for calls from the MCP Tools tab.

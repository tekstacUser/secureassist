# Incident record - SecureAssist

<!--
STUDENT EVIDENCE TEMPLATE (Task 7)

Fill this in AFTER you have run the incident drill (README section I,
docs/incident-response.md Steps 1-6). Replace EVERY "TODO" with real
information from YOUR drill: timestamps from reports/incident-timeline.log,
command output you actually saw, and the OVERALL line of
reports/verification-latest.md.

Do not invent results. If something did not work, write what really happened.

The record is complete when this prints 0:
    grep -c TODO reports/incident-record.md
scripts/verify-deployment.sh reports "Incident-response record" as FAIL while
any TODO is left (it also needs a non-empty reports/incident-timeline.log).
-->

## 1. Summary

| Field | Value |
|---|---|
| Incident ID | INC-SECUREASSIST-001 |
| Recorded by | TODO: your name |
| Date (UTC) | TODO: date of the drill |
| Severity | TODO: e.g. low - release blocked, users not affected |
| Detected at (UTC) | TODO: copy the DETECT timestamp from reports/incident-timeline.log |
| Detection method | TODO: e.g. rollout status timed out, readiness probe 503 |
| Affected component | TODO: which Deployment? |
| Affected dependency | TODO: which dependency could the new Pod not reach? |

## 2. Evidence (commands and key output)

<!-- Paste the command and the 1-3 most important lines of its REAL output. -->

| Step | Command | Key output you observed |
|---|---|---|
| Rollout | `kubectl -n secureassist rollout status deployment/secureassist-backend --timeout=60s` | TODO |
| Pods | `kubectl -n secureassist get pods -l app.kubernetes.io/name=secureassist-backend` | TODO: e.g. which Pod was 0/1 and which 1/1 |
| Events | `kubectl -n secureassist describe pod "$NEW_POD"` | TODO: the readiness-probe event |
| Readiness | `/ready` of the failing Pod | TODO: the failing check (mcp_dns ...) |
| Logs | `kubectl -n secureassist logs "$NEW_POD" ... grep readiness_failed` | TODO |
| Pod environment | `kubectl -n secureassist get pod "$NEW_POD" -o jsonpath=...` | TODO: the faulty MCP_SERVER_URL value |

## 3. Analysis

| Field | Value |
|---|---|
| Root cause | TODO: what exactly was wrong in the release? |
| User impact | TODO: e.g. none - old Pod kept serving (maxUnavailable: 0). Explain why. |
| Why the faulty Pod never received traffic | TODO: which probe protected users? |

## 4. Response and remediation

| Field | Value |
|---|---|
| Recovery action | TODO: the command you used to recover |
| Recovery started at (UTC) | TODO: RECOVER timestamp from the timeline |
| Recovered at (UTC) | TODO: RECOVERED timestamp from the timeline |
| Time to recover | TODO: RECOVERED minus DETECT (minutes) |
| Follow-up actions after recovery | TODO: e.g. restarted the port-forwards, re-ran verify-deployment.sh |

## 5. Outcome

| Field | Value |
|---|---|
| Final status | TODO: paste the OVERALL line of reports/verification-latest.md |
| Backend MCP_SERVER_URL after recovery | TODO: value shown by kubectl get deployment ... jsonpath |
| Prevention | TODO: one concrete improvement (e.g. validate URLs in Jenkins stage 8) |
| Lessons learned | TODO: one sentence |

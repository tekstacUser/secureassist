"""SecureAssist input and output guardrails.

STUDENT TASK (Task 2): Complete check_input() and check_output().

The function names, predefined rules, and supporting methods are provided.
Students must implement the TODO sections using basic Python concepts.

Design rules:
- Every check returns a GuardrailDecision with an explicit reason.
- Blocked input must not reach Ollama or MCP tools.
- Model output is treated only as text and must never be executed.
- Recognisable secrets in responses must be redacted before display.

IMPORTANT:
These simple keyword and regex checks are not complete protection
against prompt injection. They are one layer of defence-in-depth.
"""

import os
import re
from dataclasses import dataclass


MAX_PROMPT_CHARS = int(os.getenv("MAX_PROMPT_CHARS", "1000"))
MAX_RESPONSE_CHARS = int(os.getenv("MAX_RESPONSE_CHARS", "4000"))
REDACTION_TEXT = "[REDACTED]"


@dataclass(frozen=True)
class GuardrailDecision:
    allowed: bool
    reason: str
    category: str


# ------------------------------------------------------------
# Predefined rule sets - do not modify these patterns
# ------------------------------------------------------------

SECRET_REQUEST_PATTERNS = [
    r"\b(show|give|tell|reveal|print|list|dump|leak|share|send|display|expose|what\s+is|what's)\b"
    r"(\s+\w+){0,3}?\s+(passwords?|api[\s_-]?keys?|secrets?|tokens?|credentials?|private\s+keys?)\b"
    r"(?!\s+(policy|policies|reset|requirements?|rules|length|expiry|manager|change))",
    r"\b(admin|root|administrator|service[\s-]?account|database|db)\s+(password|credentials?)\b",
    r"\bkubectl\s+get\s+secrets?\b",
    r"\b(environment\s+variables?|env\s+vars?)\b.*\b(key|secret|password|token)s?\b",
    r"(/etc/shadow|/etc/passwd|id_rsa|\.ssh/)",
    r"\blangfuse[\s_-]*(secret|public)?[\s_-]*key\b",
]

PROMPT_INJECTION_PATTERNS = [
    r"\b(ignore|disregard|forget|override)\b(\s+\w+){0,3}\s+(instructions|rules|guidelines|prompts?|policies)\b",
    r"\b(system|hidden|initial)\s+prompt\b",
    r"\byou\s+are\s+now\b",
    r"\b(developer|god|dan|jailbreak)\s+mode\b",
    r"\bjailbreak\b",
    r"\b(bypass|disable|turn\s+off)\b(\s+\w+){0,2}\s+(guardrails?|filters?|safety|restrictions?)\b",
    r"\bpretend\s+(you\s+are|to\s+be)\b.*\b(admin|root|unrestricted|unfiltered)\b",
    r"\bact\s+as\s+(an?\s+)?(admin|root|unrestricted|unfiltered)\b",
]

SECRET_OUTPUT_PATTERNS = [
    r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----",
    r"\bAKIA[0-9A-Z]{16}\b",
    r"\b[sp]k-lf-[A-Za-z0-9-]{8,}\b",
    r"\bsk-[A-Za-z0-9]{20,}\b",
    r"\bgh[pousr]_[A-Za-z0-9]{20,}\b",
    r"\bglpat-[A-Za-z0-9_-]{20,}\b",
    r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b",
    r"(?i)\bbearer\s+[A-Za-z0-9._~+/-]{20,}=*",
    r"(?i)\b(password|passwd|pwd|secret|api[_-]?key|token)\s*[:=]\s*(?=\S*[0-9!@#$%^&*_])\S{6,}",
]

_SECRET_REQUEST_RE = [
    re.compile(pattern, re.IGNORECASE)
    for pattern in SECRET_REQUEST_PATTERNS
]

_INJECTION_RE = [
    re.compile(pattern, re.IGNORECASE)
    for pattern in PROMPT_INJECTION_PATTERNS
]

_SECRET_OUTPUT_RE = [
    re.compile(pattern, re.DOTALL)
    for pattern in SECRET_OUTPUT_PATTERNS
]

_CONTROL_CHARS_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


# ------------------------------------------------------------
# Input guardrail
# ------------------------------------------------------------

def check_input(message) -> GuardrailDecision:
    """Check whether a user message is safe to process."""

    # TODO 1: Check whether message is a string.
    # If it is not a string, return:
    # GuardrailDecision(False, "Message must be text.", "invalid_type")
    #
    # Hint: Use isinstance(message, str).


    # TODO 2: Remove unnecessary spaces from the beginning and end.
    # Store the cleaned message in the variable text.
    #
    # Hint: Use message.strip().


    # TODO 3: Check whether the message is empty.
    # If it is empty, return:
    # GuardrailDecision(
    #     False,
    #     "Message is empty. Please type a question.",
    #     "empty"
    # )


    # TODO 4: Check the maximum allowed prompt length.
    # If the length of text exceeds MAX_PROMPT_CHARS, return:
    # GuardrailDecision(
    #     False,
    #     f"Message is too long ({len(text)} characters). "
    #     f"Maximum is {MAX_PROMPT_CHARS}.",
    #     "too_long"
    # )
    #
    # Hint: Use len(text).


    # TODO 5: Check whether the message requests passwords,
    # API keys, tokens, or other credentials.
    #
    # Loop through _SECRET_REQUEST_RE.
    # Use pattern.search(text) to check for a match.
    #
    # If a pattern matches, return:
    # GuardrailDecision(
    #     False,
    #     "Requests for passwords, keys, tokens or other credentials "
    #     "are not allowed.",
    #     "secret_request"
    # )


    # TODO 6: Check whether the message contains a prompt-injection
    # phrase, such as "ignore previous instructions".
    #
    # Loop through _INJECTION_RE.
    # Use pattern.search(text) to check for a match.
    #
    # If a pattern matches, return:
    # GuardrailDecision(
    #     False,
    #     "The message looks like an attempt to override "
    #     "SecureAssist instructions.",
    #     "prompt_injection"
    # )


    # TODO 7: If every check passes, allow the message.
    # Return:
    # GuardrailDecision(
    #     True,
    #     "Input passed all guardrail checks.",
    #     "ok"
    # )

    pass  # Remove this line after completing the TODOs.


# ------------------------------------------------------------
# Helper method - provided implementation
# ------------------------------------------------------------

def redact_secrets(text: str) -> tuple[str, int]:
    """Replace recognisable secrets with [REDACTED]."""

    count = 0

    for pattern in _SECRET_OUTPUT_RE:
        text, number_found = pattern.subn(REDACTION_TEXT, text)
        count += number_found

    return text, count


# ------------------------------------------------------------
# Output guardrail
# ------------------------------------------------------------

def check_output(response) -> tuple[GuardrailDecision, str]:
    """Validate and sanitise a response before showing it."""

    # TODO 1: Check whether response is a string.
    # If it is not, return:
    # (GuardrailDecision(False, "Response was not text.",
    #                    "invalid_response"), "")
    #
    # Hint: Use isinstance(response, str).


    # TODO 2: Remove unwanted control characters from the response.
    # Store the cleaned result in the variable text.
    #
    # Hint:
    # _CONTROL_CHARS_RE.sub("", response).strip()


    # TODO 3: Check whether the cleaned response is empty.
    # If it is empty, return:
    # (GuardrailDecision(False, "Response was empty.",
    #                    "invalid_response"), "")


    # TODO 4: Check the maximum response length.
    # If text exceeds MAX_RESPONSE_CHARS:
    # - Keep only the first MAX_RESPONSE_CHARS characters.
    # - Remove trailing spaces.
    # - Append " ...[truncated]"
    #
    # Hint:
    # text[:MAX_RESPONSE_CHARS].rstrip()


    # TODO 5: Remove any recognisable secrets from the response.
    #
    # Hint:
    # text, redactions = redact_secrets(text)
    #
    # The helper returns the cleaned text and the number of
    # secret-like values it found.


    # TODO 6: If one or more secrets were found, return:
    # (
    #     GuardrailDecision(
    #         True,
    #         f"{redactions} secret-like value(s) redacted.",
    #         "redacted"
    #     ),
    #     text
    # )


    # TODO 7: If no secrets were found, return:
    # (
    #     GuardrailDecision(
    #         True,
    #         "Response passed output checks.",
    #         "ok"
    #     ),
    #     text
    # )

    pass  # Remove this line after completing the TODOs.

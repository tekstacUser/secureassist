"""SecureAssist frontend (PREDEFINED).

Serves the SecureAssist web application on port 8091 and PROXIES every UI
request to the backend on the server side. The browser only ever talks to
this frontend; it never connects to the backend (8092) or MCP server (8093).

Pages (one HTML page with tabs):
  GET  /                     Chat · Guardrail Tests · MCP Tools · System Status

UI API (all forwarded to the backend through its Kubernetes Service):
  POST /api/chat             -> BACKEND_URL/chat
  POST /api/guardrail-check  -> BACKEND_URL/guardrail-check
  POST /api/mcp-call         -> BACKEND_URL/mcp-call
  GET  /api/status           -> BACKEND_URL/status

Probes:
  GET  /health               frontend process alive
  GET  /ready                frontend can reach the backend /health

Environment:
  BACKEND_URL      default http://secureassist-backend:8092 (Kubernetes Service DNS)
  PROXY_TIMEOUT    seconds to wait for the backend (default 150, phi3 on CPU is slow)
  LANGFUSE_UI_URL  Langfuse address as seen by the BROWSER (default http://localhost:3031),
                   used only to build "open trace" links
"""

import os

import requests
from flask import Flask, jsonify, render_template, request

BACKEND_URL = os.getenv("BACKEND_URL", "http://secureassist-backend:8092").rstrip("/")
PROXY_TIMEOUT = float(os.getenv("PROXY_TIMEOUT", "150"))
LANGFUSE_UI_URL = os.getenv("LANGFUSE_UI_URL", "http://localhost:3031").rstrip("/")
LANGFUSE_PROJECT_ID = os.getenv("LANGFUSE_PROJECT_ID", "secureassist")
MAX_BODY_BYTES = 16 * 1024

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_BODY_BYTES


def _error(status: int, category: str, message: str):
    return jsonify({"error": {"category": category, "dependency": "backend", "message": message}}), status


def _forward(method: str, path: str, payload=None, timeout: float = PROXY_TIMEOUT):
    """Send one request to the backend and return its JSON and status code unchanged."""
    try:
        resp = requests.request(method, f"{BACKEND_URL}{path}", json=payload, timeout=(5, timeout))
    except requests.exceptions.Timeout:
        return _error(504, "backend_timeout", "The backend took too long to answer.")
    except requests.exceptions.ConnectionError:
        return _error(502, "backend_unreachable", "The SecureAssist backend is unreachable.")
    try:
        body = resp.json()
    except ValueError:
        return _error(502, "backend_invalid_response", f"Backend returned HTTP {resp.status_code} without JSON.")
    return jsonify(body), resp.status_code


def _json_body():
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else None


@app.get("/")
def index():
    return render_template("index.html", langfuse_ui_url=LANGFUSE_UI_URL,
                           langfuse_project_id=LANGFUSE_PROJECT_ID)


@app.post("/api/chat")
def api_chat():
    data = _json_body()
    if data is None or not isinstance(data.get("message"), str):
        return jsonify({"error": {"category": "invalid_json",
                                  "message": "Send JSON like {\"message\": \"...\"}"}}), 400
    return _forward("POST", "/chat", {"message": data["message"]})


@app.post("/api/guardrail-check")
def api_guardrail_check():
    data = _json_body()
    if data is None:
        return jsonify({"error": {"category": "invalid_json", "message": "JSON body required"}}), 400
    return _forward("POST", "/guardrail-check", {"text": data.get("text"), "mode": data.get("mode")}, 15)


@app.post("/api/mcp-call")
def api_mcp_call():
    data = _json_body()
    if data is None:
        return jsonify({"error": {"category": "invalid_json", "message": "JSON body required"}}), 400
    return _forward("POST", "/mcp-call", {"tool": data.get("tool"), "arguments": data.get("arguments", {})}, 30)


@app.get("/api/status")
def api_status():
    return _forward("GET", "/status", None, 30)


@app.get("/health")
def health():
    return jsonify({"status": "ok", "service": "secureassist-frontend"})


@app.get("/ready")
def ready():
    try:
        ok = requests.get(f"{BACKEND_URL}/health", timeout=3).status_code == 200
    except requests.RequestException:
        ok = False
    return jsonify({"ready": ok, "backend_url": BACKEND_URL}), (200 if ok else 503)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("FRONTEND_PORT", "8091")))

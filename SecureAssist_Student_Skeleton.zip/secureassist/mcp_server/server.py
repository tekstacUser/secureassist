"""SecureAssist MCP server.

STUDENT TASK (Task 2b): Implement the FAQ search and the two MCP tools
`search_support_faq` and `get_service_status`, and register them with the
MCP server.

A small, real Model Context Protocol (MCP) server built with the official
Python SDK (package `mcp`, pinned in requirements.txt).

Transport : MCP "Streamable HTTP" at  http://<host>:8093/mcp
Health    : plain HTTP GET             http://<host>:8093/health

It exposes exactly two SAFE, READ-ONLY tools:

  search_support_faq(query)     -> searches the predefined FAQ list below
  get_service_status(service)   -> returns SIMULATED status from the table below

Neither tool runs commands, reads files, or calls other systems. All data is
predefined in this file, so every answer is deterministic and testable.

What is PROVIDED (do not modify):
  - imports, SERVER_NAME, HOST, PORT, ALLOWED_HOSTS
  - the FAQ data (FAQS), the status table (SERVICE_STATUS), _tokens()
  - the FastMCP server object `mcp` (transport settings must match the backend client)
  - the /health route (used by the Kubernetes probes) and the start-up code

What YOU implement (numbered TODOs below):
  - TODO 1  search_faq_data()      -> keyword scoring of the FAQ list
  - TODO 2  register both tools    -> add the @mcp.tool() decorator
  - TODO 3  search_support_faq()   -> validate the query, return the result dict
  - TODO 4  get_service_status()   -> validate the service, return the status dict

The function names, parameter names, type hints and docstrings of the two tools
must stay exactly as given: MCP publishes them to the client in tools/list, and
the backend allowlist expects these exact names.

Test locally (two terminals, from the project root):
    cd mcp_server && python server.py
    curl -s http://localhost:8093/health
    cd app/backend && MCP_SERVER_URL=http://localhost:8093/mcp python mcp_client.py list
"""

import os
import re

from mcp.server.fastmcp import FastMCP
from mcp.server.transport_security import TransportSecuritySettings
from starlette.requests import Request
from starlette.responses import JSONResponse

SERVER_NAME = "secureassist-mcp"
HOST = os.getenv("MCP_HOST", "0.0.0.0")
PORT = int(os.getenv("MCP_PORT", "8093"))

# Only these Host headers are accepted (DNS-rebinding protection).
# Defaults cover the Kubernetes Service name, its FQDN, and local testing.
ALLOWED_HOSTS = [
    h.strip()
    for h in os.getenv(
        "MCP_ALLOWED_HOSTS",
        "secureassist-mcp:*,secureassist-mcp.secureassist:*,"
        "secureassist-mcp.secureassist.svc:*,"
        "secureassist-mcp.secureassist.svc.cluster.local:*,"
        "localhost:*,127.0.0.1:*",
    ).split(",")
    if h.strip()
]

# --------------------------------------------------------------------------
# Predefined project data (the ONLY data the tools can return)
# --------------------------------------------------------------------------
FAQS = [
    {
        "id": "FAQ-001",
        "title": "Reset your corporate password",
        "keywords": ["password", "reset", "forgot", "expired", "login"],
        "answer": "Open the Self-Service Portal (https://sso.example.internal/reset), "
        "choose 'Forgot password', verify with your registered MFA device and set a new "
        "password of at least 14 characters. Never share your password with anyone, "
        "including the helpdesk.",
    },
    {
        "id": "FAQ-002",
        "title": "Connect to the corporate VPN",
        "keywords": ["vpn", "remote", "connect", "tunnel", "home"],
        "answer": "Install the approved VPN client from the Software Center, sign in with "
        "your corporate account, select the gateway nearest to you and approve the MFA "
        "prompt. If it fails, restart the client and check your internet connection.",
    },
    {
        "id": "FAQ-003",
        "title": "Set up multi-factor authentication (MFA)",
        "keywords": ["mfa", "2fa", "authenticator", "multi-factor", "token", "otp"],
        "answer": "Go to the Security page of the Self-Service Portal, choose 'Register "
        "authenticator', scan the QR code with the approved authenticator app and enter "
        "the 6-digit code to confirm.",
    },
    {
        "id": "FAQ-004",
        "title": "Add a network printer",
        "keywords": ["printer", "print", "printing", "scanner"],
        "answer": "Open Settings > Printers, choose 'Add printer', and pick the printer "
        "named after your floor (for example FL3-PRINT-01). Drivers install automatically "
        "from the print server.",
    },
    {
        "id": "FAQ-005",
        "title": "Configure corporate email on a phone",
        "keywords": ["email", "mail", "outlook", "phone", "mobile"],
        "answer": "Install the approved mail app from the company app store, sign in with "
        "your corporate account and accept the device-management policy. Personal mail "
        "apps are not permitted for corporate email.",
    },
    {
        "id": "FAQ-006",
        "title": "Join the office Wi-Fi",
        "keywords": ["wifi", "wi-fi", "wireless", "network", "internet"],
        "answer": "Select the 'CORP-SECURE' network and sign in with your corporate "
        "account. Guests must use 'CORP-GUEST' with a voucher from reception.",
    },
    {
        "id": "FAQ-007",
        "title": "Request new software",
        "keywords": ["software", "install", "application", "license", "request"],
        "answer": "Raise a request in the Helpdesk Portal under 'Software'. Only software "
        "on the approved catalogue can be installed; other titles need a security review.",
    },
    {
        "id": "FAQ-008",
        "title": "Report a lost or stolen laptop",
        "keywords": ["lost", "stolen", "laptop", "device", "theft"],
        "answer": "Call the Service Desk immediately so the device can be locked and "
        "wiped remotely, then file an incident report in the Helpdesk Portal.",
    },
]

# Simulated status table. This is DEMO DATA, not live infrastructure health.
SERVICE_STATUS = {
    "email": {"status": "operational", "note": "No known issues."},
    "vpn": {"status": "degraded", "note": "Scheduled maintenance on gateway EU-2 (simulated)."},
    "sso": {"status": "operational", "note": "No known issues."},
    "wifi": {"status": "operational", "note": "No known issues."},
    "printing": {"status": "outage", "note": "Print server FL3 is offline (simulated)."},
    "helpdesk-portal": {"status": "operational", "note": "No known issues."},
}
APPROVED_SERVICES = sorted(SERVICE_STATUS)

MAX_QUERY_CHARS = 200


def _tokens(text: str) -> set[str]:
    """Provided helper: lower-case words of a text, e.g. "Reset VPN!" -> {"reset", "vpn"}."""
    return set(re.findall(r"[a-z0-9\-]+", text.lower()))


# --------------------------------------------------------------------------
# FAQ search (plain Python, no MCP yet)
# --------------------------------------------------------------------------
def search_faq_data(query: str, limit: int = 3) -> list[dict]:
    """Plain Python search used by the MCP tool (and easy to test)."""

    # TODO 1: Score every FAQ entry against the query and return the best ones.
    #
    # Step 1: Split the query into words:   words = _tokens(query)
    #
    # Step 2: Create an empty list:         scored = []
    #
    # Step 3: Loop over FAQS. For each faq calculate a score:
    #   - 2 points for every query word that is in faq["keywords"]
    #         len(words & set(faq["keywords"])) * 2
    #   - 1 point for every query word that is in the title
    #         len(words & _tokens(faq["title"]))
    #   Add both numbers together.
    #   If the score is greater than 0, append the pair (score, faq) to scored.
    #
    # Step 4: Sort: highest score first, then by FAQ id (so results are stable):
    #   scored.sort(key=lambda item: (-item[0], item[1]["id"]))
    #
    # Step 5: Return at most `limit` results, each as a NEW dictionary with
    #         exactly these keys:
    #   {"id": f["id"], "title": f["title"], "answer": f["answer"], "score": s}
    #   Hint: [ {...} for s, f in scored[:limit] ]
    #
    # Expected: search_faq_data("reset password")[0]["id"] == "FAQ-001"

    # Placeholder: remove this line after completing TODO 1.
    raise NotImplementedError("Task 2b TODO 1 not completed: search_faq_data()")


# --------------------------------------------------------------------------
# MCP server definition - provided (do not modify)
# --------------------------------------------------------------------------
# These settings must match the backend client (app/backend/mcp_client.py):
#   streamable_http_path="/mcp" -> the endpoint is http://<host>:8093/mcp
#   stateless_http=True         -> each request is independent (Kubernetes-friendly)
#   json_response=True          -> plain JSON responses instead of an SSE stream
mcp = FastMCP(
    SERVER_NAME,
    host=HOST,
    port=PORT,
    streamable_http_path="/mcp",
    stateless_http=True,
    json_response=True,
    transport_security=TransportSecuritySettings(
        enable_dns_rebinding_protection=True,
        allowed_hosts=ALLOWED_HOSTS,
        allowed_origins=[],
    ),
)


# --------------------------------------------------------------------------
# MCP tools
# --------------------------------------------------------------------------
# TODO 2: Register BOTH functions below as MCP tools.
#
# A plain Python function becomes an MCP tool when you put the decorator
#     @mcp.tool()
# on the line directly ABOVE its `def` line. Do this for search_support_faq
# AND for get_service_status (replace each "# TODO 2" marker line).
#
# Without the decorator the function exists, but MCP tools/list does not show
# it, so the backend reports the tool as not offered.

# TODO 2: add the decorator here
def search_support_faq(query: str) -> dict:
    """Search the approved IT helpdesk FAQ. Read-only. Returns up to 3 matching entries."""

    # TODO 3: Implement the FAQ tool.
    #
    # Step 1: Clean the input (it may be None):
    #   query = (query or "").strip()
    #
    # Step 2: If query is empty OR longer than MAX_QUERY_CHARS, raise:
    #   ValueError(f"query must be 1-{MAX_QUERY_CHARS} characters")
    #   (MCP sends a raised error back to the client as a tool error.)
    #
    # Step 3: Search:   results = search_faq_data(query)
    #
    # Step 4: Return this dictionary:
    #   {
    #       "query": query,
    #       "match_count": len(results),
    #       "results": results,
    #       "source": "predefined SecureAssist FAQ",
    #   }

    # Placeholder: remove this line after completing TODO 3.
    raise NotImplementedError("Task 2b TODO 3 not completed: search_support_faq()")


# TODO 2: add the decorator here
def get_service_status(service: str) -> dict:
    """Return the SIMULATED status of an approved demo service. Read-only."""

    # TODO 4: Implement the service-status tool.
    #
    # Step 1: Normalise the input (it may be None):
    #   service = (service or "").strip().lower()
    #
    # Step 2: If service is not a key of SERVICE_STATUS, raise:
    #   ValueError(f"unknown service '{service}'. Approved: {', '.join(APPROVED_SERVICES)}")
    #
    # Step 3: Return a NEW dictionary containing:
    #   - "service": service
    #   - every key/value of SERVICE_STATUS[service]  ("status" and "note")
    #   - "source": "simulated demo data - not live infrastructure health"
    #
    #   Hint: {"service": service, **SERVICE_STATUS[service], "source": "..."}
    #   The ** copies all keys of the inner dictionary.
    #
    # Expected: get_service_status("VPN") -> status "degraded"
    #           get_service_status("printing") -> status "outage"

    # Placeholder: remove this line after completing TODO 4.
    raise NotImplementedError("Task 2b TODO 4 not completed: get_service_status()")


# --------------------------------------------------------------------------
# Health route and start-up - provided (do not modify)
# --------------------------------------------------------------------------
@mcp.custom_route("/health", methods=["GET"])
async def health(_request: Request) -> JSONResponse:
    return JSONResponse({"status": "ok", "service": SERVER_NAME,
                         "tools": ["search_support_faq", "get_service_status"]})


if __name__ == "__main__":
    print(f"[{SERVER_NAME}] MCP streamable-http on http://{HOST}:{PORT}/mcp", flush=True)
    mcp.run(transport="streamable-http")

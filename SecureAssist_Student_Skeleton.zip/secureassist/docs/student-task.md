# SecureAssist — Student Tasks

Total hands-on time: **about 97 minutes** (+5 min buffer). Read time before starting: 10–15 minutes.

Every student working file contains numbered `TODO` comments that tell you exactly what to write, with hints. Work through the TODOs in number order. Unfinished code contains a placeholder line (`pass`, `raise ...`, `exit 1`, `error ...`, `TODO-...` value or `0  # TODO`) that fails on purpose — delete or replace it when you finish the TODO, so nothing can pass by accident.

## Student working files (18)
| # | File | Task |
|---:|---|:---:|
| 1 | `langfuse/.env` | 1 |
| 2 | `app/backend/guardrails.py` | 2a |
| 3 | `mcp_server/server.py` | 2b |
| 4 | `app/backend/mcp_client.py` | 2c |
| 5–7 | `app/frontend/Dockerfile`, `app/backend/Dockerfile`, `mcp_server/Dockerfile` | 3 |
| 8–13 | `k8s/frontend-deployment.yaml`, `k8s/frontend-service.yaml`, `k8s/backend-deployment.yaml`, `k8s/backend-service.yaml`, `k8s/mcp-deployment.yaml`, `k8s/mcp-service.yaml` | 4 |
| 14 | `reports/guardrail-ui-results.md` | 5 |
| 15 | `cicd/Jenkinsfile` (stages 5–10) | 6 |
| 16 | `reports/jenkins-result.md` | 6 |
| 17–18 | `reports/incident-timeline.log`, `reports/incident-record.md` | 7 |

## What is predefined (do not modify)
| Area | Files |
|---|---|
| Frontend | `app/frontend/app.py`, `templates/index.html`, `static/style.css`, `static/chat.js`, `requirements.txt`, `.dockerignore` |
| Backend | `app/backend/app.py`, `ollama_client.py`, `monitoring.py`, `requirements.txt`, `.dockerignore` |
| MCP server | `mcp_server/requirements.txt`, `.dockerignore`, `README.md` (the provided parts of `server.py` are marked *provided*) |
| Langfuse | `langfuse/Dockerfile`, `langfuse/.env.example`, `langfuse/README.md` |
| Kubernetes | `k8s/namespace.yaml`, `k8s/langfuse-*.yaml`, `k8s/secrets-template.yaml` |
| CI/CD | `sonar-project.properties`, Jenkinsfile stages 1–4 and the `post` section |
| Scripts | everything in `scripts/` |

## Task 1 — Environment checks and Langfuse secrets file (5 min) — `langfuse/.env`
Run `bash scripts/check-environment.sh`. The starter already contains `langfuse/.env` with `REPLACE_ME` placeholders and TODO comments: fill it with random values using the `sed` command in README section F, Task 1 (you can skip its `cp` line).
**Expected:** `RESULT: 0 failure(s)` (especially *Ollama from inside Minikube* and *default StorageClass*); `langfuse/.env complete`; `git check-ignore -v langfuse/.env` prints a rule.

## Task 2 — Guardrails and MCP tool security (25 min)

### 2a — Guardrails (10 min) — `app/backend/guardrails.py`
Implement the two functions by completing TODO 1–7 in each and deleting the `pass` line at the end of each function. The rule lists (`SECRET_REQUEST_PATTERNS`, `PROMPT_INJECTION_PATTERNS`, `SECRET_OUTPUT_PATTERNS`), compiled regexes and `redact_secrets()` are provided.

`check_input(message) -> GuardrailDecision`, in this order:
1. not a `str` → `(False, reason, "invalid_type")`
2. empty after `strip()` → `"empty"`
3. longer than `MAX_PROMPT_CHARS` (default 1000) → `"too_long"`, reason must mention the limit
4. any `_SECRET_REQUEST_RE` matches → `"secret_request"`
5. any `_INJECTION_RE` matches → `"prompt_injection"`
6. otherwise `(True, "Input passed all guardrail checks.", "ok")`

`check_output(response) -> (GuardrailDecision, safe_text)`:
1. not a `str` → `(False, ..., "invalid_response"), ""`
2. remove control characters, strip; empty → `"invalid_response"`, `""`
3. longer than `MAX_RESPONSE_CHARS` → cut and append `" ...[truncated]"`
4. `redact_secrets(text)`; if count > 0 → `(True, "<n> secret-like value(s) redacted.", "redacted")`
5. otherwise `(True, "Response passed output checks.", "ok"), text`

> Why order matters: type before `.strip()` (avoid crashes), length before regex (avoid slow regex on huge input).
> Limitation: keyword/regex rules are a first layer only. Rephrasing, other languages or encodings can bypass them; that is why tools are also allow-listed and read-only and output is never executed.

### 2b — MCP server tools (8 min) — `mcp_server/server.py`
The FAQ data, the simulated status table, the `FastMCP` server object (Streamable HTTP on `/mcp`, stateless, JSON responses, DNS-rebinding protection) and the `/health` route are provided.
* **TODO 1** `search_faq_data(query, limit=3)`: 2 points per keyword match + 1 point per title-word match; keep score > 0; sort by score (high first), then id; return `{id, title, answer, score}` dictionaries.
* **TODO 2** register both tools with `@mcp.tool()` (keep function names, parameters and docstrings unchanged — MCP publishes them).
* **TODO 3** `search_support_faq(query)`: 1–200 characters else `ValueError`; return `{query, match_count, results, source: "predefined SecureAssist FAQ"}`.
* **TODO 4** `get_service_status(service)`: lower-case + strip; unknown service → `ValueError`; return `{service, status, note, source: "simulated demo data - not live infrastructure health"}`.

**Check locally (optional):** `cd mcp_server && python server.py`, then `curl -s http://localhost:8093/health`.

### 2c — MCP client allowlist (7 min) — `app/backend/mcp_client.py`
The async session handling (`_with_session`, `_run`), error classification, result parsing, `check_server()` and the command line are provided.
* **TODO 1** `_validate_faq_args`: only `{"query": <1–200 chars>}` → else `MCPError("mcp_invalid_arguments", ...)`.
* **TODO 2** `_validate_status_args`: only `{"service": <name>}`, normalised, must be in `APPROVED_SERVICES`.
* **TODO 3** `ALLOWED_TOOLS`: exactly `search_support_faq` and `get_service_status`, each mapped to its validator.
* **TODO 4** `list_tools()`: `session.list_tools()` → list of `{name, description, approved}`.
* **TODO 5** `call_tool()`: unknown tool → `mcp_tool_not_allowed`; non-dict arguments → `mcp_invalid_arguments`; then validate — all **before** any network call.
* **TODO 6** inside `call_tool()`: tool not in the server's `tools/list` → `mcp_tool_not_offered`.

**Check locally (optional):** with the MCP server running, `cd app/backend && MCP_SERVER_URL=http://localhost:8093/mcp python mcp_client.py list` (2 tools, both approved) and `python mcp_client.py call run_shell '{"cmd": "id"}'` (`mcp_tool_not_allowed`).

**Check for Task 2 after deployment:** browser **🧪 Guardrail Tests → Run all tests** (Task 5), **🔧 MCP Tools** tab and the sample prompts in `docs/sample-prompts.md`. `scripts/verify-deployment.sh` re-checks the guardrail rules, MCP discovery, invocation and the allowlist inside the running backend Pod.

## Task 3 — Dockerfiles (12 min) — `app/frontend/Dockerfile`, `app/backend/Dockerfile`, `mcp_server/Dockerfile`
Each file lists TODO 1–8 in the order the instructions must appear. Each must:
* start `FROM python:3.12-slim`;
* set `PYTHONDONTWRITEBYTECODE=1`, `PYTHONUNBUFFERED=1` (recommended: `PIP_NO_CACHE_DIR=1`, `PIP_DISABLE_PIP_VERSION_CHECK=1`; MCP server also `MCP_HOST=0.0.0.0`, `MCP_PORT=8093`);
* `WORKDIR /app`, copy `requirements.txt` first and `pip install --no-cache-dir -r requirements.txt` (layer caching);
* copy only application files (frontend: `app.py templates/ static/`; backend: `app.py guardrails.py ollama_client.py mcp_client.py monitoring.py`; MCP: `server.py`);
* create user UID `10001` and `USER 10001`;
* `EXPOSE 8091` (frontend) / `EXPOSE 8092` (backend) / `EXPOSE 8093` (MCP);
* frontend/backend: `CMD ["gunicorn","--bind","0.0.0.0:<port>","--workers","2","--threads","4","--timeout","<160|150>","--access-logfile","-","app:app"]`; MCP: `CMD ["python","server.py"]`.

Then build all four project images (including the predefined `langfuse/Dockerfile`), pull `postgres:16.4-alpine`, and load all five into Minikube.
**Expected:** `docker image inspect` shows `User=10001` (or `1001` for Langfuse) and the right port; no `.env` inside any image.

## Task 4 — Kubernetes (20 min)
Files: `k8s/backend-deployment.yaml`, `k8s/backend-service.yaml`, `k8s/frontend-deployment.yaml`, `k8s/frontend-service.yaml`, `k8s/mcp-deployment.yaml`, `k8s/mcp-service.yaml`. Replace every `TODO-...` value and every `0  # TODO`, and un-comment and fill in the `____` blanks. `k8s/langfuse-deployment.yaml` is a complete, provided example of the same structure.

| Item | Backend | Frontend | MCP server |
|---|---|---|---|
| image / pullPolicy | `secureassist-backend:1.0` / `Never` | `secureassist-frontend:1.0` / `Never` | `secureassist-mcp:1.0` / `Never` |
| containerPort (name `http`) | 8092 | 8091 | 8093 |
| env | `MCP_SERVER_URL=http://secureassist-mcp:8093/mcp`, `OLLAMA_URL=http://host.minikube.internal:11434` (or the URL check-environment proved), `OLLAMA_MODEL=phi3:mini`, `LANGFUSE_HOST=http://secureassist-langfuse:3031`, `LANGFUSE_PUBLIC_KEY` / `LANGFUSE_SECRET_KEY` from Secret `secureassist-langfuse` (`optional: true`) | `BACKEND_URL=http://secureassist-backend:8092` | `MCP_HOST=0.0.0.0`, `MCP_PORT=8093` |
| readinessProbe | `GET /ready` | `GET /health` | `GET /health` |
| livenessProbe | `GET /health` | `GET /health` | `GET /health` |
| securityContext | `runAsNonRoot: true`, `runAsUser/runAsGroup: 10001`, no privilege escalation, not privileged, drop ALL, read-only root FS + `/tmp` emptyDir | same | same |
| Service | ClusterIP `secureassist-backend`, port 8092 → targetPort `http` | ClusterIP `secureassist-frontend`, port 8091 → `http` | ClusterIP `secureassist-mcp`, port 8093 → `http` |

Validate each file with `kubectl apply --dry-run=client -f <file>`. Create the Secret from `langfuse/.env`, then deploy in order: database → Langfuse → MCP → backend → frontend.
**Expected:** five Deployments `1/1`, PVC `Bound`; `kubectl -n secureassist get endpoints` shows one IP for each Service; in the browser all four header lights are green and **📊 System Status** shows every dependency *available*.

## Task 5 — Verify guardrails, MCP and Langfuse in the UI (10 min) — `reports/guardrail-ui-results.md`
Everything is done in the browser (README F Task 5, G and H; prompts in `docs/sample-prompts.md`):
1. **🧪 Guardrail Tests → Run all tests**, then **Download results** and save the file as `reports/guardrail-ui-results.md` (it replaces the placeholder).
2. Same tab: check the sample text with a fake key in **Output** mode (redaction) and a few prompts in **Input** mode.
3. **🔧 MCP Tools:** see the two discovered tools; call approved tools; call `run_shell` and `get_service_status` with `payroll-db`.
4. **💬 Chat:** FAQ, status, general and blocked sample prompts; open **Details**; click **trace ↗** to open the trace in Langfuse.
**Expected:** 17 of 17 tests passed; FAQ-001 for *reset password*; `run_shell` → `mcp_tool_not_allowed`; `payroll-db` → `mcp_invalid_arguments`; green MCP badges in the chat; the trace opens in project SecureAssist-Helpdesk.

## Task 6 — Jenkins + SonarQube (15 min) — `cicd/Jenkinsfile`, `reports/jenkins-result.md`
Complete the six TODOs in stages 5–10 (stages 1–4 are provided; keep all ten stage names and their order):
* **TODO 1 — stage 5:** stop the build with `error` when `qg.status != 'OK'`.
* **TODO 2 — stage 6:** `docker build` the four images with `$IMAGE_TAG`, `docker pull $POSTGRES_IMAGE`, write `reports/images.txt`.
* **TODO 3 — stage 7:** `minikube image load` all five images, write `reports/minikube-images.txt`, fail if fewer than 5.
* **TODO 4 — stage 8:** client-side dry run of every manifest; server-side dry run when the namespace exists.
* **TODO 5 — stage 9:** apply in dependency order, `rollout restart` four Deployments, wait for five rollouts, write `reports/k8s-status.txt`.
* **TODO 6 — stage 10:** run `scripts/verify-deployment.sh` with `VERIFY_MODE=pipeline`.

Commit and push the completed project, create the `secureassist` pipeline job (Script Path `cicd/Jenkinsfile`), build with parameters, read the console, the SonarQube quality gate and the archived `reports/`. Then replace every TODO in `reports/jenkins-result.md` with the real values.
**Expected:** build SUCCESS with stage 5 quality gate `OK`. If a stage fails because of missing permissions, record the clear failure message and ask the administrator; do not work around it with `sudo`.

## Task 7 — Incident drill (5 min) — `reports/incident-timeline.log`, `reports/incident-record.md`
Plain `kubectl` commands (README section I, full runbook in `docs/incident-response.md`): set a wrong MCP hostname with `kubectl set env` → watch the rollout get stuck → find the cause in events, logs, `/ready` and the Pod environment → `kubectl rollout undo` → wait for `rollout status` → restart the port-forwards → `bash scripts/verify-deployment.sh` (PASS) → replace every TODO in `reports/incident-record.md`. Each step writes a timestamped line to `reports/incident-timeline.log` (the first step replaces the template).
**Expected:** rollout stuck while the fault is active; healthy again after the rollback; timeline with at least five real entries; record with no TODO.

## Task 8 — Governance and final verification (5 min)
Run `bash scripts/verify-deployment.sh` until **OVERALL: PASS**, then tick `docs/governance-checklist.md`.
